<p style="text-align: center">
    [&nbsp; <a href="index.php?page=home_page&amp;section=php">PHP</a>&nbsp;]
    [&nbsp; <a href="index.php?page=home_page&amp;section=zodiac">Chinese&nbsp;Zodiac</a>&nbsp;]
</p>