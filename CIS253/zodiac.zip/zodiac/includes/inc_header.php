<h1>Chinese Zodiac</h1>
<h3>A PHP Code Demonstration</h3>